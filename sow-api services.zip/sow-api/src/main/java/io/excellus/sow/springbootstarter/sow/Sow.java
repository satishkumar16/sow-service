package io.excellus.sow.springbootstarter.sow;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sow_data_details")
public class Sow {

	private String businessUnit;
	private String msa;
	private String ContractNumber;
	
	@Id
	private int sowid;
	private int amd;
	private String sowDescription;
	private String contractType;
	private String workType;
	private String businessArea;
	private String excellusContact;
    private String sowvalue;
    private String startDate;
    private String endDate;
    private String status;
    private String recordType;
    
    public Sow() {

    }

	public Sow(String businessUnit, String msa, String contractNumber, int sowid, int amd, String sowDescription,
			String contractType, String workType, String businessArea, String excellusContact, String sowvalue,
			String startDate, String endDate, String status, String recordType) {
		super();
		this.businessUnit = businessUnit;
		this.msa = msa;
		ContractNumber = contractNumber;
		this.sowid = sowid;
		this.amd = amd;
		this.sowDescription = sowDescription;
		this.contractType = contractType;
		this.workType = workType;
		this.businessArea = businessArea;
		this.excellusContact = excellusContact;
		this.sowvalue = sowvalue;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.recordType = recordType;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getMsa() {
		return msa;
	}

	public void setMsa(String msa) {
		this.msa = msa;
	}

	public String getContractNumber() {
		return ContractNumber;
	}

	public void setContractNumber(String contractNumber) {
		ContractNumber = contractNumber;
	}

	public int getSowid() {
		return sowid;
	}

	public void setSowid(int sowid) {
		this.sowid = sowid;
	}

	public int getAmd() {
		return amd;
	}

	public void setAmd(int amd) {
		this.amd = amd;
	}

	public String getSowDescription() {
		return sowDescription;
	}

	public void setSowDescription(String sowDescription) {
		this.sowDescription = sowDescription;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}

	public String getExcellusContact() {
		return excellusContact;
	}

	public void setExcellusContact(String excellusContact) {
		this.excellusContact = excellusContact;
	}

	public String getSowvalue() {
		return sowvalue;
	}

	public void setSowvalue(String sowvalue) {
		this.sowvalue = sowvalue;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	
	
	
}
    