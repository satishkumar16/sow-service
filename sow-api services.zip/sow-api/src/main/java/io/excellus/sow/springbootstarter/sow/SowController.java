package io.excellus.sow.springbootstarter.sow;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class SowController {

	@Autowired  
	private SowService sowService;
		        	  
		
	@GetMapping("/getsow")
	public List<Sow> SowDetail() {
	  return sowService.SowDetail();
	  			  		  
   }
		 
	 
	@PostMapping("/addsow")
	public void addSowDetails(@RequestBody Sow sow) {
	  	    sowService.addSowDetail(sow);	
		 
	 }
		  
	
	@PutMapping("/updatesow/{sownum}")
	public void updateSowDetails(@PathVariable int sownum,@RequestBody Sow sow) {
	  	    sowService.updateSowDetail(sownum, sow);
		 
	 }
	
	@DeleteMapping("/deletesow/{sownum}")
	public String deleteSowDetails(@PathVariable int sownum) {
	  	    sowService.deleteSowDetail(sownum);
	  	  return ("Sow deleted successsfully");
		 
	 }
	
		 
	
  }
	
	

