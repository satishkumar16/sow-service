package io.excellus.sow.springbootstarter.sow;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.excellus.sow.springbootstarter.sow.Repository.SowRepository;

@Service 
public class SowService {
	
	@Autowired
    private SowRepository sowrepository;	
   
	/* Get all sow's details */
	public List<Sow> SowDetail() {
       	return (List<Sow>) sowrepository.findAll();
    }
	
	
	/* add a sow details */
	public void addSowDetail(Sow sow) {
       	 sowrepository.save(sow);
    }
   
	
	/* update a sow details */
	public void updateSowDetail(int id, Sow sow) {
      	 sowrepository.save(sow);
   }
	
	
	/* delete a sow details */
    public void deleteSowDetail(int id) {
       	sowrepository.deleteById(id);
    
    }
    
   
   
}



