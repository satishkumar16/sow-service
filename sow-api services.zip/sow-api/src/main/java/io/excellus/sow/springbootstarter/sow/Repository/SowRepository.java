package io.excellus.sow.springbootstarter.sow.Repository;
import io.excellus.sow.springbootstarter.sow.Sow;
import org.springframework.data.repository.CrudRepository;

public interface SowRepository extends CrudRepository<Sow, Integer> {

	}	
	
	


